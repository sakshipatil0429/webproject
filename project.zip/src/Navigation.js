// Navigation.js
import React from 'react';
import { Layout, Menu } from 'antd';
import { HomeOutlined, UserOutlined, AppstoreOutlined, HeartOutlined, StarOutlined, ProfileOutlined, FormOutlined  } from '@ant-design/icons';
import { Link } from 'react-router-dom';


const { Sider } = Layout;

const Navigation = () => {
  return (
    <Sider
      width={200}
      theme="dark"
      breakpoint="md"
      collapsedWidth="0"
      style={{
        height: '100vh',
        overflow: 'auto',
        position: 'fixed',
        left: 0,
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Menu theme="dark" mode="vertical" defaultSelectedKeys={['1']} style={{ height: '100%' }}>
  <Menu.Item key="0" icon={<UserOutlined />}>
    <Link to="/myprofile">Profile</Link>
  </Menu.Item>
  <Menu.Item key="1" icon={<HomeOutlined />}>
    <Link to="/">Home</Link>
  </Menu.Item>
  <Menu.Item key="2" icon={<HeartOutlined />}>
    <Link to="/like">Like</Link>
  </Menu.Item>
  <Menu.Item key="3" icon={<StarOutlined />}>
    <Link to="/bookmark">Bookmark</Link>
  </Menu.Item>
  <Menu.Item key="4" icon={<ProfileOutlined />}>
    <Link to="/mypost">My Post</Link>
  </Menu.Item>
  <Menu.Item key="5" icon={<FormOutlined />}>
    <Link to="/newpost">New Post</Link>
  </Menu.Item>
</Menu>

    </Sider>
  );
};

export default Navigation;
