// Profile.js
import React from 'react';

const Profile = () => {
  return (
    <>
      <div className="profile">
        <center>
          <h2>My Profile</h2>
        </center>

        <div className="form-item">
          <div className="profile-photo">
            {/* Placeholder for profile photo (no functionality to upload images in HTML/CSS) */}
            {/* <img src="logo192.png" alt="Profile Picture" /> */}
          </div>
          <input type="file" id="profilePhoto" name="profilePhoto" />
          <button>Upload</button>
        </div>

        <div className="form-item">
          <label htmlFor="name">Name</label>
          <div className="edit-section">
            <input type="text" id="name" name="name" value="ABC" />
            <button>Edit</button>
          </div>
        </div>

        <div className="form-item">
          <label htmlFor="email">Email ID</label>
          <input type="text" id="email" name="email" value="abc@email.com" readOnly />
        </div>

        {/* Any other fields you'd like to include */}
        <button type="submit">Save</button>
      </div>
    </>
  );
};

export default Profile;
