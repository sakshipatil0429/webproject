// Bookmark.js
import React, { useState, useEffect } from 'react';
import { Card, Row, Col, Typography, Pagination, Button } from 'antd';
import { BookOutlined } from '@ant-design/icons';
import { ProCard } from '@ant-design/pro-card';

const { Meta } = Card;
const { Title, Text } = Typography;

const Bookmark = () => {
  // Example bookmarked posts data
  const [bookmarkedPosts, setBookmarkedPosts] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const postsPerPage = 10;

  useEffect(() => {
    // Fetch bookmarked posts data from an API or database
    // For demonstration purposes, we'll use a static list
    const fetchData = async () => {
      // Replace this with your actual data fetching logic
      // Example: const response = await fetch('your-api-endpoint');
      // const data = await response.json();
      
      // Static example data with only title and content
      const exampleData = Array.from({ length: 30 }, (_, index) => ({
        id: index + 1,
        title: `Bookmarked Post ${index + 1}`,
        content: `This is the content of the bookmarked post number ${index + 1}.`,
      }));

      setBookmarkedPosts(exampleData);
    };

    fetchData();
  }, []); // Empty dependency array ensures that the effect runs only once on component mount

  // Calculate current posts to display based on pagination
  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const currentPosts = bookmarkedPosts.slice(indexOfFirstPost, indexOfLastPost);

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const handleUnbookmark = (postId) => {
    // Handle unbookmark action (update the bookmarkedPosts state or send to the server)
    console.log(`Unbookmarked post with ID ${postId}`);
  };

  return (
    <div style={{ padding: '20px' }}>
      <Title level={2}>Your Bookmarked Posts</Title>
      {currentPosts.length === 0 ? (
        <Text type="secondary">No bookmarked posts yet.</Text>
      ) : (
        <>
          <Row gutter={[16, 16]}>
            {currentPosts.map(post => (
              <Col key={post.id} xs={24} sm={12} md={8} lg={6}>
                <ProCard
                  hoverable
                  style={{ width: '100%' }}
                  bodyStyle={{ padding: '12px' }}
                  bordered
                >
                  <Card>
                    <Meta title={post.title} description={post.content} />
                  </Card>
                  <Row justify="end" align="middle" style={{ marginTop: '8px' }}>
                    <Button
                      type="text"
                      icon={<BookOutlined />}
                      onClick={() => handleUnbookmark(post.id)}
                    >
                      Unbookmark
                    </Button>
                  </Row>
                </ProCard>
              </Col>
            ))}
          </Row>
          <Pagination
            current={currentPage}
            pageSize={postsPerPage}
            total={bookmarkedPosts.length}
            onChange={handlePageChange}
            style={{ marginTop: '16px', textAlign: 'center' }}
          />
        </>
      )}
    </div>
  );
};

export default Bookmark;
