import React, { useState } from 'react';
import { Form, Input, Button, Avatar, Upload, message } from 'antd';
import { UserOutlined, EditOutlined, LoadingOutlined, PlusOutlined } from '@ant-design/icons';
import './Profile.css';

const MyProfile = () => {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [imageUrl, setImageUrl] = useState(null);

  const handleSaveProfile = async () => {
    try {
      const values = await form.validateFields();
      // Handle saving the edited profile (send to server or perform any desired action)
      console.log('Edited Profile:', values);
      form.resetFields();
    } catch (error) {
      console.error('Error saving profile:', error);
    }
  };

  const beforeUpload = (file) => {
    const isJpgOrPng = file.type === 'image/jpeg' || file.type === 'image/png';
    if (!isJpgOrPng) {
      message.error('You can only upload JPG/PNG file!');
    }
    const isLt2M = file.size / 1024 / 1024 < 2;
    if (!isLt2M) {
      message.error('Image must be smaller than 2MB!');
    }
    return isJpgOrPng && isLt2M;
  };

  const handleChange = (info) => {
    if (info.file.status === 'uploading') {
      setLoading(true);
      return;
    }
    if (info.file.status === 'done') {
      // Get this url from response in the real world.
      setLoading(false);
      setImageUrl(info.file.response.url); // Assuming the server sends the URL of the uploaded image
    }
  };

  const uploadButton = (
    <div className="upload-overlay">
      {loading ? <LoadingOutlined /> : <PlusOutlined />}
      <div className="edit-icon">
        <EditOutlined style={{ fontSize: '20px', color: '#fff' }} />
      </div>
    </div>
  );

  return (
    <div className="profile">
      <center>
        <h2>My Profile</h2>
      </center>

      <Upload
        name="avatar"
        listType="picture-card"
        showUploadList={false}
        beforeUpload={beforeUpload}
        onChange={handleChange}
      >
        <div className="avatar-container">
          {imageUrl ? (
            <Avatar size={150} src={imageUrl} />
          ) : (
            <div className="default-avatar">
              <img src="logo192.png" alt="Default Avatar" />
            </div>
          )}
          {uploadButton}
        </div>
      </Upload>

      <Form form={form} onFinish={handleSaveProfile}>
        <Form.Item
          name="name"
          label="Name"
          initialValue="ABC"
          rules={[{ required: true, message: 'Please enter your name!' }]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          name="email"
          label="Email ID"
          initialValue="abc@email.com"
          rules={[{ required: true, message: 'Please enter your email!' }]}
        >
          <Input readOnly />
        </Form.Item>

        

        <Button type="submit" className="upload-button" onClick={handleSaveProfile}>
          Save
        </Button>
      </Form>
    </div>
  );
};

export default MyProfile;
