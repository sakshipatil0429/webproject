// Like.js
import React, { useState } from 'react';
import { Card, Button, Avatar } from 'antd';
import { LikeOutlined, HeartOutlined, HeartFilled, StarOutlined, StarFilled } from '@ant-design/icons';

const { Meta } = Card;

const getRandomName = () => {
  const names = ['Alice', 'Bob', 'Charlie', 'David', 'Eva', 'Frank', 'Grace', 'Henry', 'Ivy', 'Jack'];
  const randomIndex = Math.floor(Math.random() * names.length);
  return names[randomIndex];
};

const getRandomPhoto = () => {
  const photoNumbers = Array.from({ length: 10 }, (_, index) => index + 1);
  const randomPhotoNumber = photoNumbers[Math.floor(Math.random() * photoNumbers.length)];
  return `https://via.placeholder.com/50/0000FF/808080?text=${randomPhotoNumber}`;
};

const getRandomContent = () => {
  const contents = [
    'This is a great post!',
    'I totally agree with this.',
    'Interesting thoughts!',
    'Well said!',
    'I appreciate your perspective.',
    'Thanks for sharing!',
  ];
  const randomIndex = Math.floor(Math.random() * contents.length);
  return contents[randomIndex];
};

const getRandomDate = () => {
  const startDate = new Date(2023, 0, 1);
  const endDate = new Date();
  const randomDate = new Date(startDate.getTime() + Math.random() * (endDate.getTime() - startDate.getTime()));
  return randomDate.toLocaleDateString();
};

const getRandomLikes = () => Math.floor(Math.random() * 10);

const getRandomBookmarks = () => Math.floor(Math.random() * 5);

const getRandomPost = (id) => ({
  id,
  owner: { name: getRandomName(), photo: getRandomPhoto() },
  date: getRandomDate(),
  content: getRandomContent(),
  likes: getRandomLikes(),
  bookmarks: getRandomBookmarks(),
});

const Like = () => {
  const [visiblePosts, setVisiblePosts] = useState(10);
  const [posts] = useState(Array.from({ length: 20 }, (_, index) => getRandomPost(index + 1)));

  const handleLike = (postId) => {
    // Handle like logic
  };

  const handleBookmark = (postId) => {
    // Handle bookmark logic
  };

  const handleLoadMore = () => {
    setVisiblePosts(prevVisiblePosts => prevVisiblePosts + 10);
  };

  return (
    <div>
      {posts.slice(0, visiblePosts).map(post => (
        <Card
          key={post.id}
          style={{ margin: '16px 0'}}
          actions={[
            <span>
              {post.likes} {post.likes === 1 ? 'Like' : 'Likes'}
              <Button
                icon={post.likes > 0 ? <HeartFilled /> : <HeartOutlined />}
                onClick={() => handleLike(post.id)}
                style={{ marginLeft: 8 }}
              />
            </span>,
            <span>
              {post.bookmarks} {post.bookmarks === 1 ? 'Bookmark' : 'Bookmarks'}
              <Button
                icon={post.bookmarks > 0 ? <StarFilled /> : <StarOutlined />}
                onClick={() => handleBookmark(post.id)}
                style={{ marginLeft: 8 }}
              />
            </span>,
          ]}
        >
          <Meta
            avatar={<Avatar src={post.owner.photo} />}
            title={post.owner.name}
            description={`Posted on ${post.date}`}
          />
          <p>{post.content}</p>
        </Card>
      ))}
      {visiblePosts < posts.length && (
        <Button type="primary" onClick={handleLoadMore} style={{ margin: '16px 0' }}>
          Load More
        </Button>
      )}
    </div>
  );
};

export default Like;
