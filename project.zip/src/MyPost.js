// MyPosts.js
import React, { useState } from 'react';
import { Table, Space, Button, Modal, Form, Input, message } from 'antd';
import { EditOutlined, DeleteOutlined, CommentOutlined } from '@ant-design/icons';

const { confirm } = Modal;

const MyPosts = () => {
  // Example posts data
  const [posts, setPosts] = useState(Array.from({ length: 20 }, (_, index) => ({
    id: index + 1,
    title: `Post ${index + 1}`,
    content: `This is the content of post ${index + 1}.`,
    comments: Array.from({ length: Math.floor(Math.random() * 5) }, (_, commentIndex) => `Comment ${commentIndex + 1}`),
  })));

  const [editingPost, setEditingPost] = useState(null);

  // Columns configuration for the table
  const columns = [
    {
      title: 'Title',
      dataIndex: 'title',
      key: 'title',
    },
    {
      title: 'Content',
      dataIndex: 'content',
      key: 'content',
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (_, record) => (
        <Space>
          <Button icon={<EditOutlined />} onClick={() => handleEdit(record)} type="primary">
            Edit
          </Button>
          <Button icon={<DeleteOutlined />} onClick={() => showDeleteConfirm(record)} danger>
            Delete
          </Button>
          <Button icon={<CommentOutlined />} onClick={() => showComments(record)} type="default">
            Comments
          </Button>
        </Space>
      ),
    },
  ];

  const handleEdit = (record) => {
    setEditingPost(record);
    showEditModal(record);
  };

  const showDeleteConfirm = (record) => {
    confirm({
      title: 'Are you sure you want to delete this post?',
      icon: <DeleteOutlined />,
      content: record.title,
      okText: 'Yes',
      okType: 'danger',
      cancelText: 'No',
      onOk() {
        handleDelete(record.id);
      },
      onCancel() {
        console.log('Cancel');
      },
    });
  };

  const handleDelete = (postId) => {
    // Handle delete action (update the posts state or send to the server)
    const updatedPosts = posts.filter(post => post.id !== postId);
    setPosts(updatedPosts);
    message.success('Post deleted successfully!');
  };

  const showEditModal = (record) => {
    Modal.confirm({
      title: 'Edit Post',
      content: (
        <Form
          initialValues={record}
          onFinish={(values) => handleUpdate(values, record.id)}
        >
          <Form.Item
            label="Title"
            name="title"
            rules={[{ required: true, message: 'Please enter the title!' }]}
          >
            <Input />
          </Form.Item>
          <Form.Item
            label="Content"
            name="content"
            rules={[{ required: true, message: 'Please enter the content!' }]}
          >
            <Input.TextArea />
          </Form.Item>
          <Form.Item>
            <Button type="primary" htmlType="submit">
              Save Changes
            </Button>
          </Form.Item>
        </Form>
      ),
      okText: 'Save',
      cancelText: 'Cancel',
    });
  };

  const handleUpdate = (values, postId) => {
    // Handle update action (update the posts state or send to the server)
    const updatedPosts = posts.map(post =>
      post.id === postId ? { ...post, ...values } : post
    );
    setPosts(updatedPosts);
    setEditingPost(null);
    message.success('Post updated successfully!');
  };

  const showComments = (record) => {
    // Show comments for the selected post
    Modal.info({
      title: 'Comments',
      content: (
        <ul>
          {record.comments.map((comment, index) => (
            <li key={index}>{comment}</li>
          ))}
        </ul>
      ),
      okText: 'Close',
    });
  };

  return (
    <Table
      dataSource={posts}
      columns={columns}
      expandable={{
        expandedRowRender: (record) => (
          <p style={{ margin: 0 }}>{record.comments.join(', ')}</p>
        ),
        rowExpandable: (record) => record.comments.length > 0,
      }}
    />
  );
};

export default MyPosts;
