// NewPost.js
import React, { useState } from 'react';
import { Card, Form, Input, Button } from 'antd';

const { TextArea } = Input;

const NewPost = () => {
  const [form] = Form.useForm();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async () => {
    try {
      setIsSubmitting(true);
      const values = await form.validateFields();
      // Handle the submission of the new post (you can send it to your server or perform any desired action)
      console.log('New Post:', values);
      // Reset the form after successful submission
      form.resetFields();
    } catch (error) {
      console.error('Error submitting post:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card title="Create a New Post" style={{ width: 600, margin: '20px auto' }}>
      <Form form={form} onFinish={handleSubmit}>
        <Form.Item
          name="title"
          label="Post Title"
          rules={[{ required: true, message: 'Please enter your post title!' }]}
        >
          <Input placeholder="Enter the title of your post" />
        </Form.Item>
        <Form.Item
          name="content"
          label="Post Content"
          rules={[{ required: true, message: 'Please enter your post content!' }]}
        >
          <TextArea rows={4} placeholder="What's on your mind?" />
        </Form.Item>
        <Form.Item>
          <Button type="primary" htmlType="submit" loading={isSubmitting}>
            Post
          </Button>
        </Form.Item>
      </Form>
    </Card>
  );
};

export default NewPost;
