// App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { Layout } from 'antd';
import Navigation from './Navigation';
import Home from './Home';
import MyProfile from './MyProfile';
import Like from './LIke';
import Bookmark from './Bookmark';
import MyPost from './MyPost';
import NewPost from './NewPost';
import './App.css';


const { Content } = Layout;

const App = () => {
  return (
    
      <Layout style={{ minHeight: '100vh' }}>
        <Navigation />
        <Layout style={{ marginLeft: 200, minHeight: '100vh' }}>
          <Content style={{ margin: '24px 16px 0', overflow: 'initial' }}>
            <div style={{ padding: 24, background: '#fff', minHeight: '100%'}}>
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/myprofile" element={<MyProfile />} />
                <Route path="/like" element={<Like />} />
                <Route path="/bookmark" element={<Bookmark />} />
                <Route path="/mypost" element={<MyPost />} />
                <Route path="/newpost" element={<NewPost />} />
                []
                {/* Add more routes as needed */}
              </Routes>
            </div>
          </Content>
        </Layout>
      </Layout>
    
  );
};

export default App;
